# meta-heuristicas
trabalhos praticos de meta-heuristicas
